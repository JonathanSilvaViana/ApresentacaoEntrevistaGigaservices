<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>

        <div class="row center">
            <h1 class="header center blue-grey-text">Selecione uma opção</h1>
        </div>
        <div class="row center animated bounceInUp">
            <div class="row">
                <a href="/sistema/categorias.php" class="btn-large waves-effect waves-light blue darken-3">
                    Categorias
                </a>
            </div>
            <div class="row">
                <a href="http://localhost/sistema/produtos.php" class="btn-large waves-effect waves-light blue darken-3">Produtos</a>
            </div>
        </div>
        <br><br>

    </div>
</div>