<ul class="right hide-on-med-and-down">
    <li><a href="index.php"><i class="material-icons large left">home</i></a></li>
</ul>

<ul id="nav-mobile" class="sidenav indigo accent-4">
    <li><a class="white-text" href="index.php">Home<i class="material-icons large left white-text">home</i></a></li>
</ul>

<a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>