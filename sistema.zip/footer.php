<footer class="page-footer blue darken-3">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="white-text">Texto</h5>
                <p class="grey-text text-lighten-4">

                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed dolor libero. Quisque consequat massa a libero lobortis bibendum. Aliquam ut luctus orci. Sed elementum finibus volutpat. Donec scelerisque iaculis ipsum, vitae fringilla dolor placerat non. Donec tempus vitae velit at mollis. Vivamus mattis non neque accumsan aliquam. Proin auctor odio vel fringilla pulvinar. Integer porta, nisi ut congue mollis, ipsum mauris sagittis libero, congue fringilla turpis odio quis metus. Vivamus pretium venenatis urna, quis ullamcorper ex viverra nec. Nulla lobortis id lacus nec ultricies. Aliquam erat volutpat. Praesent id facilisis magna. Donec neque diam, tincidunt mollis lacinia sed, lobortis ac velit.

                </p>


            </div>

        </div>
    </div>
    <div class="footer-copyright">
        &nbsp;
    </div>
</footer>