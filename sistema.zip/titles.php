<?php

$presentation = "Apresentação";
$title_Home = "Teste prático - Menu inicial";
$title_Categories  = "Lista Categoria";
$title_Details_Categories = "Detalhes categorias";
$title_Products = "Lista produtos";
$title_Details_Products = "Detalhes produtos";

